#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys

from csv2html.example import Example

if __name__ == "__main__":
	an_example = Example()
	sys.exit(an_example.main())
